"use strict";

const http = require("node:http");
const path = require("node:path");
const fs = require("node:fs/promises");

const { scrape2dGalleriesProfile } = require("./src/scraper");

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || "127.0.0.1";
const PUBLIC_DIR = path.join(__dirname, "public");

const MIME_TYPES = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml"
};

function setCorsHeaders(res) {
  res.setHeader("access-control-allow-origin", "*");
  res.setHeader("access-control-allow-methods", "GET,POST,HEAD,OPTIONS");
  res.setHeader("access-control-allow-headers", "content-type");
}

function sendJson(res, statusCode, payload) {
  const data = JSON.stringify(payload);

  setCorsHeaders(res);
  res.writeHead(statusCode, {
    "cache-control": "no-store",
    "content-type": "application/json; charset=utf-8"
  });

  res.end(data);
}

function sendText(res, statusCode, text) {
  setCorsHeaders(res);
  res.writeHead(statusCode, {
    "cache-control": "no-store",
    "content-type": "text/plain; charset=utf-8"
  });

  res.end(text);
}

async function readRequestBody(req) {
  const chunks = [];

  for await (const chunk of req) {
    chunks.push(chunk);
  }

  return Buffer.concat(chunks).toString("utf8");
}

async function parseJsonBody(req) {
  const bodyText = await readRequestBody(req);

  if (!bodyText) {
    return {};
  }

  try {
    return JSON.parse(bodyText);
  } catch {
    throw new Error("Request body must be valid JSON.");
  }
}

function getSafePublicFilePath(requestPath) {
  const normalizedRequestPath = requestPath === "/" ? "index.html" : requestPath.replace(/^\/+/, "");
  const resolvedPath = path.normalize(normalizedRequestPath).replace(/^([.][.][/\\])+/, "");
  const absolutePath = path.join(PUBLIC_DIR, resolvedPath);

  const allowedPrefix = `${PUBLIC_DIR}${path.sep}`;
  if (absolutePath !== PUBLIC_DIR && !absolutePath.startsWith(allowedPrefix)) {
    return null;
  }

  return absolutePath;
}

async function serveStaticFile(req, res, pathname) {
  let normalizedPathname = pathname;

  if (normalizedPathname === "/public" || normalizedPathname === "/public/") {
    normalizedPathname = "/";
  } else if (normalizedPathname === "/public/index.html") {
    normalizedPathname = "/";
  } else if (normalizedPathname.startsWith("/public/")) {
    normalizedPathname = normalizedPathname.replace(/^\/public/, "");
  }

  const filePath = getSafePublicFilePath(normalizedPathname);
  if (!filePath) {
    sendText(res, 403, "Forbidden");
    return;
  }

  try {
    const fileContent = await fs.readFile(filePath);
    const extension = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[extension] || "application/octet-stream";

    setCorsHeaders(res);
    res.writeHead(200, {
      "cache-control": "no-store",
      "content-type": contentType
    });

    if (req.method === "HEAD") {
      res.end();
      return;
    }

    res.end(fileContent);
  } catch (error) {
    if (error && error.code === "ENOENT") {
      sendText(res, 404, "Not Found");
      return;
    }

    console.error(error);
    sendText(res, 500, "Internal Server Error");
  }
}

async function handleApi(req, res, urlObj) {
  if (req.method === "GET" && urlObj.pathname === "/api/health") {
    sendJson(res, 200, {
      ok: true,
      service: "data-entry-browser-module"
    });
    return true;
  }

  if (req.method === "POST" && urlObj.pathname === "/api/scrape") {
    try {
      const body = await parseJsonBody(req);
      const targetUrl = typeof body.url === "string" ? body.url.trim() : "";

      if (!targetUrl) {
        sendJson(res, 400, {
          ok: false,
          error: "Please provide a profile URL in `url`."
        });
        return true;
      }

      const scrapeResult = await scrape2dGalleriesProfile(targetUrl);

      sendJson(res, 200, {
        ok: true,
        ...scrapeResult
      });
      return true;
    } catch (error) {
      sendJson(res, 400, {
        ok: false,
        error: error instanceof Error ? error.message : "Scrape failed"
      });
      return true;
    }
  }

  if (urlObj.pathname.startsWith("/api/")) {
    sendJson(res, 404, {
      ok: false,
      error: "API endpoint not found"
    });
    return true;
  }

  return false;
}

const server = http.createServer(async (req, res) => {
  try {
    if (!req.url || !req.method) {
      sendText(res, 400, "Bad Request");
      return;
    }

    if (req.method === "OPTIONS") {
      setCorsHeaders(res);
      res.writeHead(204);
      res.end();
      return;
    }

    const urlObj = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    const apiHandled = await handleApi(req, res, urlObj);

    if (apiHandled) {
      return;
    }

    if (req.method !== "GET" && req.method !== "HEAD") {
      sendText(res, 405, "Method Not Allowed");
      return;
    }

    await serveStaticFile(req, res, urlObj.pathname);
  } catch (error) {
    console.error(error);
    sendText(res, 500, "Internal Server Error");
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Data entry browser module running at http://${HOST}:${PORT}`);
});
