"use strict";

const PLACEHOLDER_IMAGE =
  "data:image/svg+xml;charset=UTF-8," +
  encodeURIComponent(
    "<svg xmlns='http://www.w3.org/2000/svg' width='132' height='92' viewBox='0 0 132 92'><rect width='132' height='92' fill='#f7eddc'/><rect x='8' y='8' width='116' height='76' rx='8' fill='#fff7ec' stroke='#dcb98a'/><circle cx='44' cy='41' r='13' fill='#ffd19d'/><path d='M22 68 L48 49 L66 61 L82 46 L110 68 Z' fill='#9dcab3'/><text x='66' y='84' text-anchor='middle' font-size='10' fill='#725538' font-family='Trebuchet MS'>No image</text></svg>"
  );

const state = {
  activeMode: "manual",
  entries: [],
  profile: null
};

const API_BASE_URL = window.location.protocol === "file:" ? "http://127.0.0.1:3000" : "";

const elements = {
  clearListButton: document.querySelector("#clear-list"),
  emptyState: document.querySelector("#empty-state"),
  entriesBody: document.querySelector("#entries-body"),
  listMeta: document.querySelector("#list-meta"),
  manualForm: document.querySelector("#manual-form"),
  modeSections: document.querySelectorAll(".mode-section"),
  profileForm: document.querySelector("#profile-form"),
  profileSummary: document.querySelector("#profile-summary"),
  pdfForm: document.querySelector("#pdf-form"),
  scrapeForm: document.querySelector("#scrape-form"),
  scrapeStatus: document.querySelector("#scrape-status"),
  tabButtons: document.querySelectorAll(".tab")
};

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function normalizeText(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function entryKey(entry) {
  return normalizeText(entry.artworkUrl || `${entry.artworkTitle}|${entry.artistName}|${entry.imageUrl}|${entry.source}`);
}

function statusClass(type) {
  if (type === "ok") {
    return "ok";
  }

  if (type === "warn") {
    return "warn";
  }

  return "error";
}

function setScrapeStatus(type, message) {
  const cssClass = statusClass(type);

  elements.scrapeStatus.className = `status ${cssClass}`;
  elements.scrapeStatus.textContent = message;
  elements.scrapeStatus.classList.remove("hidden");
}

function clearScrapeStatus() {
  elements.scrapeStatus.classList.add("hidden");
  elements.scrapeStatus.className = "status hidden";
  elements.scrapeStatus.textContent = "";
}

function toSafeImageUrl(url) {
  const text = normalizeText(url);
  if (!text) {
    return PLACEHOLDER_IMAGE;
  }

  if (/^https?:\/\//i.test(text) || /^data:image\//i.test(text)) {
    return text;
  }

  return PLACEHOLDER_IMAGE;
}

function renderEntries() {
  elements.entriesBody.innerHTML = "";

  state.entries.forEach((entry, index) => {
    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${index + 1}</td>
      <td><img class="thumb" src="${escapeHtml(toSafeImageUrl(entry.imageUrl))}" alt="${escapeHtml(entry.artworkTitle)}"></td>
      <td>${escapeHtml(entry.artworkTitle)}</td>
      <td>${escapeHtml(entry.artistName)}</td>
      <td>${escapeHtml(entry.source)}</td>
    `;

    elements.entriesBody.appendChild(row);
  });

  elements.listMeta.textContent = `${state.entries.length} entr${state.entries.length === 1 ? "y" : "ies"} loaded`;
  elements.emptyState.classList.toggle("hidden", state.entries.length > 0);
}

function addEntries(entries) {
  const knownKeys = new Set(state.entries.map(entryKey));

  for (const rawEntry of entries) {
    const entry = {
      artworkTitle: normalizeText(rawEntry.artworkTitle) || "Untitled artwork",
      artistName: normalizeText(rawEntry.artistName) || "Unknown artist",
      artworkUrl: normalizeText(rawEntry.artworkUrl),
      imageUrl: normalizeText(rawEntry.imageUrl),
      source: normalizeText(rawEntry.source) || "Unknown"
    };

    const key = entryKey(entry);
    if (!knownKeys.has(key)) {
      knownKeys.add(key);
      state.entries.push(entry);
    }
  }

  renderEntries();
}

function renderProfileSummary() {
  if (!state.profile) {
    elements.profileSummary.classList.add("hidden");
    elements.profileSummary.innerHTML = "";
    return;
  }

  const profile = state.profile;

  elements.profileSummary.innerHTML = `
    <strong>Collector saved:</strong> ${escapeHtml(`${profile.firstName} ${profile.lastName}`)}<br>
    Preferred method: ${escapeHtml(profile.ingestMethod)}<br>
    Optional details: age=${escapeHtml(profile.age || "-")}, location=${escapeHtml(profile.location || "-")}, email=${escapeHtml(profile.email || "-")}
  `;
  elements.profileSummary.classList.remove("hidden");
}

function setActiveMode(mode) {
  state.activeMode = mode;

  elements.tabButtons.forEach((button) => {
    const active = button.dataset.mode === mode;
    button.classList.toggle("active", active);
  });

  elements.modeSections.forEach((section) => {
    const active = section.id === `mode-${mode}`;
    section.classList.toggle("hidden", !active);
  });

  if (mode !== "scrape") {
    clearScrapeStatus();
  }
}

function onProfileSubmit(event) {
  event.preventDefault();

  if (!elements.profileForm.reportValidity()) {
    return;
  }

  const data = new FormData(elements.profileForm);

  state.profile = {
    age: normalizeText(data.get("age")),
    email: normalizeText(data.get("email")),
    firstName: normalizeText(data.get("firstName")),
    ingestMethod: normalizeText(data.get("ingestMethod")) || "manual",
    lastName: normalizeText(data.get("lastName")),
    location: normalizeText(data.get("location"))
  };

  renderProfileSummary();
  setActiveMode(state.profile.ingestMethod);
}

function onManualSubmit(event) {
  event.preventDefault();

  if (!elements.manualForm.reportValidity()) {
    return;
  }

  const data = new FormData(elements.manualForm);

  addEntries([
    {
      artworkTitle: data.get("artworkTitle"),
      artistName: data.get("artistName"),
      imageUrl: data.get("imageUrl"),
      source: "Manual"
    }
  ]);

  elements.manualForm.reset();
}

function onPdfSubmit(event) {
  event.preventDefault();

  if (!elements.pdfForm.reportValidity()) {
    return;
  }

  const data = new FormData(elements.pdfForm);
  const file = data.get("pdfFile");
  const fallbackImage = data.get("imageUrl");

  addEntries([
    {
      artworkTitle: data.get("artworkTitle"),
      artistName: data.get("artistName"),
      imageUrl: fallbackImage,
      source: file && typeof file.name === "string" ? `PDF (${file.name})` : "PDF"
    }
  ]);

  elements.pdfForm.reset();
}

async function onScrapeSubmit(event) {
  event.preventDefault();

  if (!elements.scrapeForm.reportValidity()) {
    return;
  }

  const button = elements.scrapeForm.querySelector("button[type='submit']");
  const urlValue = normalizeText(new FormData(elements.scrapeForm).get("profileUrl"));

  button.disabled = true;
  setScrapeStatus("warn", "Scraping in progress...");

  try {
    const response = await fetch(`${API_BASE_URL}/api/scrape`, {
      method: "POST",
      headers: {
        "content-type": "application/json"
      },
      body: JSON.stringify({
        url: urlValue
      })
    });

    const payload = await response.json();

    if (!response.ok || !payload.ok) {
      throw new Error(payload.error || "Scrape request failed.");
    }

    const scrapedEntries = (payload.entries || []).map((entry) => ({
      ...entry,
      source: "Scrape"
    }));

    addEntries(scrapedEntries);

    if (payload.expectedCount == null) {
      setScrapeStatus("warn", `Scraped ${payload.foundCount} artworks.`);
    } else if (payload.meetsExpectedCount) {
      setScrapeStatus(
        "ok",
        `Scrape completed: found ${payload.foundCount} artworks, matching expected profile count (${payload.expectedCount}).`
      );
    } else {
      setScrapeStatus(
        "warn",
        `Scrape completed: found ${payload.foundCount} artworks, while the profile advertises ${payload.expectedCount}. Some works may be private or currently unavailable.`
      );
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "";
    const fallbackMessage =
      window.location.protocol === "file:"
        ? "Cannot reach scraping API from file:// mode. Keep `node server.js` running and open http://127.0.0.1:3000/."
        : "Unexpected scrape error";

    const userMessage = errorMessage && !/failed to fetch/i.test(errorMessage) ? errorMessage : fallbackMessage;
    setScrapeStatus("error", userMessage);
  } finally {
    button.disabled = false;
  }
}

function onClearList() {
  state.entries = [];
  renderEntries();
  clearScrapeStatus();
}

function bindEvents() {
  elements.profileForm.addEventListener("submit", onProfileSubmit);
  elements.manualForm.addEventListener("submit", onManualSubmit);
  elements.pdfForm.addEventListener("submit", onPdfSubmit);
  elements.scrapeForm.addEventListener("submit", onScrapeSubmit);
  elements.clearListButton.addEventListener("click", onClearList);

  elements.tabButtons.forEach((button) => {
    button.addEventListener("click", () => setActiveMode(button.dataset.mode));
  });
}

function init() {
  bindEvents();
  setActiveMode("manual");
  renderEntries();
}

init();
