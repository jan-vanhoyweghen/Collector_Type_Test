#!/usr/bin/env python3
"""Data entry browser module server (Python fallback when Node.js is unavailable)."""

from __future__ import annotations

import json
import os
import posixpath
import re
import sys
from dataclasses import dataclass
from html import unescape
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict, List, Optional
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse
from urllib.request import Request, urlopen

HOST = os.environ.get("HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT", "3000"))
PUBLIC_DIR = Path(__file__).resolve().parent / "public"

TWO_DG_HOST = "www.2dgalleries.com"
TWO_DG_BASE_URL = f"https://{TWO_DG_HOST}"

MIME_TYPES = {
    ".css": "text/css; charset=utf-8",
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".svg": "image/svg+xml",
}

DEFAULT_HEADERS = {
    "accept-language": "en-US,en;q=0.9",
    "user-agent": "DataEntryPOC/1.0 (+https://localhost)",
}


def normalize_spaces(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def clean_text(text: str) -> str:
    no_tags = re.sub(r"<[^>]*>", " ", text or "")
    return normalize_spaces(unescape(no_tags))


def to_absolute_url(value: str) -> str:
    if not value:
        return ""
    if re.match(r"^https?://", value, re.IGNORECASE):
        return value
    if value.startswith("/"):
        return f"{TWO_DG_BASE_URL}{value}"
    return f"{TWO_DG_BASE_URL}/{value}"


@dataclass
class ArtworkEntry:
    artworkTitle: str
    artistName: str
    artworkUrl: str
    imageUrl: str


def fetch_html(url: str) -> str:
    request = Request(url=url, headers=DEFAULT_HEADERS)
    try:
        with urlopen(request, timeout=20) as response:
            return response.read().decode("utf-8", errors="replace")
    except HTTPError as error:
        raise ValueError(f"Request failed for {url} with status {error.code}.") from error
    except URLError as error:
        raise ValueError(f"Network error while requesting {url}: {error.reason}") from error


def assert_2dg_profile_url(input_url: str) -> str:
    try:
        parsed = urlparse(input_url)
    except ValueError as error:
        raise ValueError("Invalid URL provided.") from error

    host = (parsed.hostname or "").lower()
    path = parsed.path or ""

    is_valid_host = host == TWO_DG_HOST or host.endswith(f".{TWO_DG_HOST}")
    is_profile_path = re.match(r"^/profile/.+", path, re.IGNORECASE) is not None

    if not is_valid_host or not is_profile_path:
        raise ValueError(
            "Only 2DGalleries profile URLs are allowed (example: https://www.2dgalleries.com/profile/jan)."
        )

    query_items = dict(parse_qsl(parsed.query, keep_blank_values=True))
    query_items["lang"] = "en"

    return urlunparse(
        (
            parsed.scheme or "https",
            parsed.netloc,
            parsed.path,
            parsed.params,
            urlencode(query_items),
            parsed.fragment,
        )
    )


def extract_user_id(profile_html: str) -> int:
    match = re.search(r"/userartworks/(\d+)", profile_html, re.IGNORECASE)
    if not match:
        raise ValueError("Could not detect the profile user id from 2DGalleries page.")
    return int(match.group(1))


def extract_expected_count(profile_html: str, user_id: int) -> Optional[int]:
    direct = re.search(
        rf"<a\s+href=\"/userartworks/{user_id}\"[^>]*>\s*(\d+)\s+artworks?\s*</a>",
        profile_html,
        re.IGNORECASE,
    )
    if direct:
        return int(direct.group(1))

    fallback = re.search(r"All artworks[^0-9]*(\d+)", profile_html, re.IGNORECASE)
    if fallback:
        return int(fallback.group(1))

    return None


def split_artwork_blocks(page_html: str) -> List[str]:
    parts = page_html.split('<div class="artworkcontainer">')[1:]
    return [f'<div class="artworkcontainer">{item}' for item in parts]


def parse_artwork_block(block_html: str) -> Optional[ArtworkEntry]:
    artwork_path_match = re.search(r'<a class="img"\s+href="([^"]+)"', block_html, re.IGNORECASE)
    if not artwork_path_match:
        return None

    image_path_match = re.search(r'<img[^>]+src="([^"]+)"', block_html, re.IGNORECASE)
    title_match = re.search(r"<h3[^>]*>([\s\S]*?)</h3>", block_html, re.IGNORECASE)

    artist_matches = re.findall(r'<a class="artist"[^>]*>([\s\S]*?)</a>', block_html, re.IGNORECASE)
    artists = [clean_text(item) for item in artist_matches if clean_text(item)]

    title = clean_text(title_match.group(1) if title_match else "") or "Untitled artwork"
    artist_name = ", ".join(artists) if artists else "Unknown artist"

    return ArtworkEntry(
        artworkTitle=title,
        artistName=artist_name,
        artworkUrl=to_absolute_url(artwork_path_match.group(1)),
        imageUrl=to_absolute_url(image_path_match.group(1) if image_path_match else ""),
    )


def find_next_offset(page_html: str, current_offset: int) -> Optional[int]:
    matches = re.findall(r'data-url="/userartworks/\d+\?uid=\d+&\s*offset=(\d+)"', page_html, re.IGNORECASE)
    higher = [int(item) for item in matches if int(item) > current_offset]
    return min(higher) if higher else None


def scrape_2dg_profile(profile_url: str) -> Dict[str, object]:
    safe_profile_url = assert_2dg_profile_url(profile_url)
    profile_html = fetch_html(safe_profile_url)

    profile_user_id = extract_user_id(profile_html)
    expected_count = extract_expected_count(profile_html, profile_user_id)

    collected: List[ArtworkEntry] = []
    visited_offsets = set()
    current_offset = 0

    for _ in range(100):
        if current_offset in visited_offsets:
            break

        visited_offsets.add(current_offset)

        page_url = (
            f"{TWO_DG_BASE_URL}/userartworks/{profile_user_id}"
            f"?uid={profile_user_id}&offset={current_offset}&ajx=1&pager=1&hr=1&pid={profile_user_id}"
        )
        page_html = fetch_html(page_url)

        page_entries = [
            parsed
            for parsed in (parse_artwork_block(block) for block in split_artwork_blocks(page_html))
            if parsed is not None
        ]

        if not page_entries:
            break

        collected.extend(page_entries)

        next_offset = find_next_offset(page_html, current_offset)
        if next_offset is None:
            break

        current_offset = next_offset

    deduped: List[ArtworkEntry] = []
    seen = set()

    for entry in collected:
        key = entry.artworkUrl or f"{entry.artworkTitle}|{entry.artistName}|{entry.imageUrl}"
        if key not in seen:
            seen.add(key)
            deduped.append(entry)

    entries_payload = [
        {
            "artworkTitle": item.artworkTitle,
            "artistName": item.artistName,
            "artworkUrl": item.artworkUrl,
            "imageUrl": item.imageUrl,
        }
        for item in deduped
    ]

    return {
        "sourceUrl": safe_profile_url,
        "profileUserId": profile_user_id,
        "expectedCount": expected_count,
        "foundCount": len(entries_payload),
        "meetsExpectedCount": None if expected_count is None else len(entries_payload) == expected_count,
        "entries": entries_payload,
    }


class AppHandler(BaseHTTPRequestHandler):
    server_version = "DataEntryModule/0.1"

    def do_OPTIONS(self) -> None:
        self.send_response(HTTPStatus.NO_CONTENT)
        self._set_cors_headers()
        self.end_headers()

    def do_HEAD(self) -> None:
        self._handle_request(with_body=False)

    def do_GET(self) -> None:
        self._handle_request(with_body=True)

    def do_POST(self) -> None:
        self._handle_request(with_body=True)

    def log_message(self, fmt: str, *args: object) -> None:
        sys.stdout.write("%s - - [%s] %s\n" % (self.client_address[0], self.log_date_time_string(), fmt % args))

    def _set_cors_headers(self) -> None:
        self.send_header("access-control-allow-origin", "*")
        self.send_header("access-control-allow-methods", "GET,POST,HEAD,OPTIONS")
        self.send_header("access-control-allow-headers", "content-type")

    def _send_json(self, status: int, payload: Dict[str, object], with_body: bool = True) -> None:
        encoded = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self._set_cors_headers()
        self.send_header("cache-control", "no-store")
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-length", str(len(encoded)))
        self.end_headers()
        if with_body:
            self.wfile.write(encoded)

    def _send_text(self, status: int, text: str, with_body: bool = True) -> None:
        encoded = text.encode("utf-8")
        self.send_response(status)
        self._set_cors_headers()
        self.send_header("cache-control", "no-store")
        self.send_header("content-type", "text/plain; charset=utf-8")
        self.send_header("content-length", str(len(encoded)))
        self.end_headers()
        if with_body:
            self.wfile.write(encoded)

    def _send_file(self, status: int, file_path: Path, with_body: bool = True) -> None:
        content = file_path.read_bytes()
        extension = file_path.suffix.lower()
        mime = MIME_TYPES.get(extension, "application/octet-stream")

        self.send_response(status)
        self._set_cors_headers()
        self.send_header("cache-control", "no-store")
        self.send_header("content-type", mime)
        self.send_header("content-length", str(len(content)))
        self.end_headers()
        if with_body:
            self.wfile.write(content)

    def _handle_request(self, with_body: bool) -> None:
        parsed = urlparse(self.path)

        if parsed.path == "/api/health" and self.command == "GET":
            self._send_json(HTTPStatus.OK, {"ok": True, "service": "data-entry-browser-module"}, with_body=with_body)
            return

        if parsed.path == "/api/scrape" and self.command == "POST":
            self._handle_scrape(with_body=with_body)
            return

        if parsed.path.startswith("/api/"):
            self._send_json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "API endpoint not found"}, with_body=with_body)
            return

        if self.command not in {"GET", "HEAD"}:
            self._send_text(HTTPStatus.METHOD_NOT_ALLOWED, "Method Not Allowed", with_body=with_body)
            return

        self._serve_static(parsed.path, with_body=with_body)

    def _handle_scrape(self, with_body: bool) -> None:
        try:
            raw_length = self.headers.get("content-length")
            length = int(raw_length) if raw_length else 0
        except ValueError:
            self._send_json(HTTPStatus.BAD_REQUEST, {"ok": False, "error": "Invalid content length"}, with_body=with_body)
            return

        body_bytes = self.rfile.read(length) if length > 0 else b"{}"
        try:
            body = json.loads(body_bytes.decode("utf-8"))
        except json.JSONDecodeError:
            self._send_json(
                HTTPStatus.BAD_REQUEST,
                {"ok": False, "error": "Request body must be valid JSON."},
                with_body=with_body,
            )
            return

        target_url = str(body.get("url", "")).strip()
        if not target_url:
            self._send_json(
                HTTPStatus.BAD_REQUEST,
                {"ok": False, "error": "Please provide a profile URL in `url`."},
                with_body=with_body,
            )
            return

        try:
            result = scrape_2dg_profile(target_url)
        except Exception as error:  # pylint: disable=broad-except
            self._send_json(HTTPStatus.BAD_REQUEST, {"ok": False, "error": str(error)}, with_body=with_body)
            return

        payload = {"ok": True, **result}
        self._send_json(HTTPStatus.OK, payload, with_body=with_body)

    def _serve_static(self, request_path: str, with_body: bool) -> None:
        normalized = request_path

        if normalized in {"/public", "/public/", "/public/index.html"}:
            normalized = "/"
        elif normalized.startswith("/public/"):
            normalized = normalized[len("/public") :]

        if normalized in {"", "/"}:
            normalized_rel = "index.html"
        else:
            normalized_rel = posixpath.normpath(normalized.lstrip("/"))

        if normalized_rel.startswith("../"):
            self._send_text(HTTPStatus.FORBIDDEN, "Forbidden", with_body=with_body)
            return

        file_path = (PUBLIC_DIR / normalized_rel).resolve()

        try:
            file_path.relative_to(PUBLIC_DIR.resolve())
        except ValueError:
            self._send_text(HTTPStatus.FORBIDDEN, "Forbidden", with_body=with_body)
            return

        if not file_path.exists() or not file_path.is_file():
            self._send_text(HTTPStatus.NOT_FOUND, "Not Found", with_body=with_body)
            return

        self._send_file(HTTPStatus.OK, file_path, with_body=with_body)


def main() -> None:
    server = ThreadingHTTPServer((HOST, PORT), AppHandler)
    print(f"Data entry browser module running at http://{HOST}:{PORT}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
